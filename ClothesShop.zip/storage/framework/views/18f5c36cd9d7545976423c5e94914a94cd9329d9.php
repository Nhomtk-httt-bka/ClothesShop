<div class="container">
	<h2 class="my-4">Category</h2>	
	<ul class="navbar-nav ml-auto">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="nav-item category">
	          	<a class="nav-link" href="<?php echo e(url('category/' . $category->id)); ?>"><?php echo e($category->category_name); ?></a>
	        </li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>


