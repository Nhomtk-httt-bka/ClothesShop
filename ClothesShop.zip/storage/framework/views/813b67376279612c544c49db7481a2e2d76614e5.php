<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Clothes Store</title>
    
    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/modern-business.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('css/comment.css')); ?>" rel="stylesheet">
  
  </head>
    
  <body>
    <!-- Core plugin JavaScript-->
    <!-- <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script> -->

    <!-- Bootstrap core JavaScript -->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <?php echo $__env->make('component.navbar_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div style="margin: 6px;"></div>
    <?php if(Request::is('home')): ?>
      <?php echo $__env->make('component.slide_show', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    
    <div class="row">
        <?php if(Request::is('home')): ?>
            <div class="col-md-2 border border-dark rounded border-left-0">
                <?php echo $__env->make('component.sidebar_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-10">
        <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    
    <!-- The Modal -->
    <div class="modal fade" id="cart">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <!-- Modal header -->
          <div class="modal-header">
            <h4 class="modal-title">Shopping Cart </h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <!-- Modal body -->
          <div class="modal-body">
            <div>
              <?php $cart = session('cart') ?>
              <?php if(session()->has('cart')): ?>
               
                <table class="table">
                  <thead>
                    <th scope="col">image</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Action</th>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <tr>
                        <td><img src="<?php echo e(asset('img/products/'. $product->product_image )); ?>" alt="product" height="30px" width="40px;"></td>
                        <td><?php echo e($product->product_name); ?></td>
                        <?php 
                          $sub = substr($product->product_price,-3);
                          $pre = substr($product->product_price,0,-3);
                          $price = $pre . '.' .$sub;
                        ?>
                        <td><?php echo e($price); ?> đ</td>
                        <td><input class="form-control" type="number" min=1 value="<?php echo e($product->quantity); ?>"></td>
                        <td><button id="<?php echo e($product->id); ?>" onclick="rmProduct(this)" class="btn btn-danger">x</button></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    
                  </tbody>
                </table>
              <?php endif; ?>
            </div>
          </div>
          <!-- Modal footer -->
          <div class="modal-footer">
            <?php if(session()->has('cart')): ?>
              <a href="<?php echo e(url('carts')); ?>" class="btn btn-primary" >Checkout</a>
            <?php endif; ?>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
    <?php echo $__env->make('component.footer_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
  <script>

    function rmProduct(el){
        var product_id = el.getAttribute('id');

        var cart = <?php echo json_encode($cart); ?>;
        
              
        
        var data = {
          _token: "<?php echo e(csrf_token()); ?>",
          product_id: product_id
        };
        $(document).ready(function(){
            $.ajax({
                url: "<?php echo e(url('rmProduct')); ?>",
                method: 'post',
                async: true,
                data: data,
                success: function(result) {
                    $(el).parent().parent().remove();
                },
                error: function() {
                    alert('Sorry have error , please load again this page');
                },
            });
            
        });
    }
  </script>
</html>




