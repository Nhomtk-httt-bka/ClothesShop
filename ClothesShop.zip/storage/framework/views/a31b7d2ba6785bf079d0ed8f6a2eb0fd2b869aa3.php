<html>

  <head>
    <title>Login Clothes Shop</title>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/login-user.css')); ?>">
    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

    
  </head>
  
  <body>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    
    
    <div class="container">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    
  </body>

</html>
