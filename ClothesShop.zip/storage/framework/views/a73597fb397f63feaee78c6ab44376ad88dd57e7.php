<?php $__env->startSection('content'); ?>
  <div class="card card-login mx-auto mt-5">
    <div class="card-header">Login Admin</div>
    <div class="card-body">
      <form action="<?php echo e(url('admin/login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <div class="form-label-group">
            <input name="email" type="email" id="inputEmail" class="form-control" placeholder="Email address" required="required" autofocus="autofocus">
            <label for="inputEmail">Email address</label>
          </div>
        </div>
        <div class="form-group">
          <div class="form-label-group">
            <input name="password" type="password" id="inputPassword" class="form-control" placeholder="Password" required="required">
            <label for="inputPassword">Password</label>
          </div>
        </div>
        <div class="form-group">
          <div class="checkbox">
            <label>
              <input type="checkbox" value="remember-me">
              Remember Password
            </label>
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Login</button>
      </form>
      <div class="text-center">
        <a class="d-block small mt-3" href="<?php echo e(url('admins/create')); ?>">Register an Account</a>
        <a class="d-block small" href="">Forgot Password?</a>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>