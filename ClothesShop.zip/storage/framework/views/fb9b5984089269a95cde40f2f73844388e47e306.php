<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<br>
		<?php if($errors->any()): ?>
          <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($errors->first()); ?></strong>
          </div>
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
          <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e(session('success')); ?></strong>
          </div>
        <?php endif; ?>
		<h4><?php echo e($product->product_name); ?></h4>
		<hr>
		<div class="row">
			<div class="col-md-4">
				<div class="container text-md-center">
					<img src="<?php echo e(asset('img/products/' . $product->product_image )); ?>" height="500" width="100%" alt="image product">	
				</div>
			</div>
			<div class="col-md-6">
				<h4>
					<span class="text-danger">Trạng thái: </span>
					<?php if($product->product_condition == 0 ): ?>
						ngừng kinh doanh
					<?php elseif($product->product_condition == 1): ?>
						đang kinh doanh  
					<?php elseif($product->product_condition == 2): ?>
						đang hết hàng
					<?php endif; ?>
				</h4>	
				
				<!-- Search Widget -->
		        <div class="card mb-4">
		            <h5 class="card-header">Content</h5>
		            <div class="card-body">
		              <div class="input-group">
		                <h4><?php echo e($product->product_content); ?></h4>
		              </div>
		            </div>
		        </div>
				<input class="form-control" type="text" value="<?php echo e($product->product_quantity); ?>" readonly>
				<br>
				<div class="row">
					<div class="col-md-6">
						<a class="btn btn-warning" style="width: 100%" href="<?php echo e(url('carts')); ?>">Shopping cart</a>
					</div>
					<div class="col-md-6">
						<form action="<?php echo e(url('carts')); ?>" method="post">
							<?php echo csrf_field(); ?>
							<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
							<button class="btn btn-danger" style="width: 100%" 
							<?php if($product->product_condition != 1): ?>
								disabled
							<?php endif; ?>

							> Thêm vào giỏ</button>	
						</form>
						
					</div>
				</div>
				
			</div>		
			<div class="col-md-2">
				<h4>Sidebar ckeckout</h4>
			</div>
		</div>

		<hr><br>
		
		<div class="container-fluid">
			<div class="card text-white bg-info mb-3" style="max-width: 100rem;">
			  <div class="card-header">Description</div>
			  <div class="card-body">
			    
			    <p class="card-text"><?php echo e($product->product_description); ?></p>
			  </div>
			</div>
		</div>
		
		
		
		<div class="comments">
			<div class="comment-wrap">
				<div class="photo">
					<?php if(auth()->guard()->check()): ?>
          				<div class="avatar" style="background-image: url('<?php echo e(asset('storage/' . Auth::user()->user_image)); ?>'); background-size: cover;"></div>
        			<?php endif; ?>
					
				</div>
				<div class="comment-block">
					<form action="<?php echo e(url('comments')); ?>" method="post">
						<?php echo csrf_field(); ?>
						
						<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
						<div class="form-group">
						  <textarea name="comment_content" class="form-control" rows="5" id="comment"></textarea>
						</div>
						<?php if(auth()->guard()->check()): ?>
							<input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
							<button class="btn btn-primary" type="submit"><i class="fa fa-reply"></i> Comment</button> 
						<?php endif; ?>
					</form>
				</div>
			</div>
			<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="comment-wrap">
					<div class="photo">
						<div class="avatar" style="background-image: url('<?php echo e(asset('storage/' . $comment['image'])); ?>'); background-size: cover;" ></div>
					</div>
					<div class="comment-block">
						<p class="comment-text"><?php echo e($comment['comment_content']); ?></p>
						<div class="bottom-comment">
							<div class="comment-date"><?php echo e($comment['created_at']); ?></div>
								
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			
			

		</div>
			  
		<br>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.bg_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>